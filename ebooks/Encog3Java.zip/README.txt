Programming Neural Networks with Encog3 in Java
Copyright 2011, Heaton Research, Inc.  

Thankyou for purchasing this ebook.

http://www.heatonresearch.com/encog

This book can be purchased from the following URL.

http://www.heatonresearch.com/book/programming-neural-networks-encog3-java.html


For the complete list of books offered, visit this URL.

http://www.heatonresearch.com/book


There are three formats in this file.  PDF is most suitable if you want to 
see this book in a fixed layout, similar to a paper book.  MOBI and EPUB 
allow reflowable text and will look much better than the PDF when viewed 
on an ereader.

PDF � Standard ebook format, suitable for printing.
MOBI � Used for the Amazon Kindle and others.
EPUB � Used for the iPad, Nook and others.

