Artificial Intelligence for Humans, Volume 1: Fundamental Algorithms
Copyright 2013, Heaton Research, Inc.  

Thank you for purchasing this ebook. This book is copyrighted material,
please do not redistribute.

This book can be purchased from the following URL.

http://www.heatonresearch.com/book/aifh-vol1-fundamental.html

This book's source code can be found here:

https://github.com/jeffheaton/aifh

For the complete list of books offered, visit this URL.

http://www.heatonresearch.com/book


There are three formats in this file.  PDF is most suitable if you want to 
see this book in a fixed layout, similar to a paper book.  MOBI and EPUB 
allow reflowable text and will look much better than the PDF when viewed 
on an ereader.

PDF        - Standard ebook format, suitable for printing.
MOBI & AZW - Used for the Amazon Kindle and others.
EPUB       - Used for the iPad, Nook and others.

